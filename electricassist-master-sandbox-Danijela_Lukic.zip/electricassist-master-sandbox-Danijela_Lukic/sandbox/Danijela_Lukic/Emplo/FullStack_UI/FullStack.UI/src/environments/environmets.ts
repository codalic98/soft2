export const environment=
{
    product:false,
    baseApiUrl:'https://localhost:7040'
};